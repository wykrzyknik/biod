
  $(document).ready(function() {

    if(typeof jQuery().loadModal !== "undefined") {
      $('#edit-password').loadModal();
    }
  });
