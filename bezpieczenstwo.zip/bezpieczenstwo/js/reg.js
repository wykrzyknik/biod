function scorePassword(pass) {
    var wynik = 0;
    var warianty = {
        cyfry: /\d/.test(pass),
        male: /[a-z]/.test(pass),
        duze: /[A-Z]/.test(pass),
        specjalne: /\W/.test(pass),
        dlugosc: pass.length > 7
    };
    for(var war in warianty)
      if(warianty[war] == true) wynik += 100 / 5;

    var color = '';
    var text = '';

    if(wynik < 100){ color ='red' ; text = 'słabe' ;}
    else if(wynik == 100){ color = 'green' ; text = 'mocne ';}
    $("#strength_score").text(text);
    $("#strength_score").css('background-color', color);
    return parseInt(wynik);
}

$(function() {
    $("#password").on("keypress keyup keydown", function() {
        scorePassword($(this).val());
    });
});
