<?php

function printDate()
{
  $data = date("d-m-Y");
  echo($data);
}

function printTime()
{
  $czas = date("G:i");
  echo($czas);
}
?>
