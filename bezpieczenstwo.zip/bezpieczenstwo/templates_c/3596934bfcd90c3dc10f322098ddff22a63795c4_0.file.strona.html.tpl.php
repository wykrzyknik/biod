<?php
/* Smarty version 3.1.33, created on 2019-06-03 15:33:45
  from 'C:\xampp\htdocs\bezpieczenstwo\templates\Access\strona.html.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cf521b954faa6_49890916',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3596934bfcd90c3dc10f322098ddff22a63795c4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\bezpieczenstwo\\templates\\Access\\strona.html.tpl',
      1 => 1559568415,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5cf521b954faa6_49890916 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20890805225cf521b9547da8_75259762', 'title');
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6732225735cf521b954bc25_14819118', 'body');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../baseTemplate.html.tpl");
}
/* {block 'title'} */
class Block_20890805225cf521b9547da8_75259762 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'title' => 
  array (
    0 => 'Block_20890805225cf521b9547da8_75259762',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
Strona Główna<?php
}
}
/* {/block 'title'} */
/* {block 'body'} */
class Block_6732225735cf521b954bc25_14819118 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'body' => 
  array (
    0 => 'Block_6732225735cf521b954bc25_14819118',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<h5><span style="color:black">Bezpieczeństwo i ochrona danych osobowych 2019 </span></h4></br>

<?php
}
}
/* {/block 'body'} */
}
