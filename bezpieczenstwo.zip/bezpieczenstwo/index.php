<?php
  require 'vendor/autoload.php';

new \Controllers\Main();
		

?>
